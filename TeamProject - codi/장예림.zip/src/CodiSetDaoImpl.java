import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import kr.co.greenart.dbutil.DBUtil;

public class CodiSetDaoImpl implements CodiSetDao {
	
	@Override
	public int createCodi(CodiSet set) throws SQLException {
		String query = "INSERT INTO codiset_new (product1, product2, product3, product4, product5, product6, product7, codiset_image, user_id, tag_theme) VALUES (?, ?, ?, ? ,? ,?, ?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, set.getProduct1());
			pstmt.setString(2, set.getProduct2());
			pstmt.setString(3, set.getProduct3());
			pstmt.setString(4, set.getProduct4());
			pstmt.setString(5, set.getProduct5());
			pstmt.setString(6, set.getProduct6());
			pstmt.setString(7, set.getProduct7());
			pstmt.setBlob(8, set.getCodiset_image());
			pstmt.setString(9, set.getUser_id());
			pstmt.setString(10, set.getTag_theme());
			
			return pstmt.executeUpdate();
			
		} finally {
			DBUtil.closeStmt(pstmt);
			DBUtil.closeConn(conn);
		}

	}
	
}
