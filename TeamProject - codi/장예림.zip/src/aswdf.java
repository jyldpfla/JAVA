import java.sql.SQLException;

public class aswdf {
	public static void main(String[] args) throws SQLException {
		ManagementDaoImpl a = new ManagementDaoImpl();
//		System.out.println(a.read_Top().get(0).getImageUrl());
		
	}
}

