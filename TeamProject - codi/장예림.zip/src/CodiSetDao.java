import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;


public interface CodiSetDao {
	int createCodi(CodiSet set) throws SQLException;
//	CodiSet readCodi() throws SQLException;
//	List<CodiSet> readCodiList() throws SQLException;
//	CodiSet updateCodi() throws SQLException;
//	CodiSet deleteCodi() throws SQLException;
}
